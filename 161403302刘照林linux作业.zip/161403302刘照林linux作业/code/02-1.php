<!DOCTYPE html>
<html lang="zh">

<head>
    <meta charset="gb2312">
    <title>明日方舟</title>
</head>

<body>
	<h1 style="color:#FF0066">明日方舟攻略(AK tools)</h1>
	<h2 font-size="1000px">由于游戏刚刚正式上线，数据不足，暂不做攻略处理,很抱歉</h2>
	<input align="center" name="" align="center" type="'submit" value="返回主页" style="width:60px" onClick=history.back();>

</body>

</html>
