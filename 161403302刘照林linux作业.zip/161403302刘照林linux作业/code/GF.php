<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="gb2312">   
    <title>少女前线工具</title>
</head>

<body background="m16.png">
	<table width="100%">
		<tr>
			<td style="font-size:36px" bgcolor="CCCCCC"><Font-color="FF3300">少女前线工具(GF tools) by 刘照林</td> 
		</tr>
        </table>
<p>

        <table bgcolor="#CCCCCC">
		<tr>
			<td style="font-size:30px"><a href="GF-后勤.php">后勤排序器&nbsp;&nbsp;|</a></td> 
			<td rowspan="5" style="font-size:30px">&nbsp;&nbsp;首页<p>&nbsp;&nbsp;少女前线工具简单版<p>&nbsp;&nbsp;所有部分内容存放于对应的页面中</td> 
		</tr>
		<tr>
			<td style="font-size:30px"><a href="GF-练级.php">练级计算器&nbsp;&nbsp;|</a></td> 
		</tr>
		<tr>
			<td style="font-size:30px"><a href="GF-建造.php">建造模拟器&nbsp;&nbsp;|</a></td> 
		</tr>
		<tr>
			<td style="font-size:30px"><a href="GF-芯片.php">芯片模拟器&nbsp;&nbsp;|</a></td> 
		</tr>
		<tr>
			<td style="font-size:30px"><a href="GF-掉落.php">掉落统计&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|</a></td> 
		</tr>
		<tr>
			<td style="font-size:30px"><a href="01.php">返回首页&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|</a></td> 
		</tr>
	</table>

</body>

</html>
