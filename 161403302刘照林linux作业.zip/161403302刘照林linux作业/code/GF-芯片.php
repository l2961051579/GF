<!DOCTYPE html>
<html lang="zh">

<head>
    <meta charset="gb2312">
    <title>少女前线</title>
</head>

<body>
	<h1 style="color:#FF0066">芯片模拟器(GF tools)</h1>
	<h2 font-size="1000px">由于未知因素及本人水平有限，本模块功能暂不开放</h2>
	<input align="center" name="" align="center" type="'submit" value="返回主页" style="width:60px" onClick=history.back();>

</body>

</html>
